import logo from "./logo.svg";
import "./App.css";
import { useState } from "react";

function App() {
  const [man, setMan] = useState("");
  const [hide, setHide] = useState(false);
  let content = "";
  function move(man) {
    // let url = `https://gn.go.kr/www/selectEmployeeList.do?key=735&searchDeptCode=&searchCnd=all&searchKrwd=${man}`;

    window.location.href = `https://gn.go.kr/www/selectEmployeeList.do?key=735&searchDeptCode=&searchCnd=all&searchKrwd=${man}`;
  }

  return (
    <div className="canvas">
      <h1>어떤 짐승을 고르겠슴미다?</h1>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          if (event.target.man.value != "direct") {
            setMan(event.target.man.value);
            console.log(man);
            move(event.target.man.value);
          } else {
            setMan(event.target.manDirect.value);
            console.log(man);
            move(event.target.manDirect.value);
          }
        }}
      >
        <select
          name="man"
          id="selectContainer"
          onChange={(event) => {
            if (event.target.value === "direct") {
              let selectContainer = document.getElementById("selectContainer");
              selectContainer.classList.add("directOption");
              let formInput = document.getElementById("formInput");
              formInput.classList.remove("hide");
            } else {
              let selectContainer = document.getElementById("selectContainer");
              selectContainer.classList.remove("directOption");
              let formInput = document.getElementById("formInput");
              formInput.classList.add("hide");
            }
          }}
        >
          <option value="오승욱">캉 가 루</option>
          <option value="박찬혁">왈 라 비</option>
          <option value="홍기원">홍 기 원</option>
          <option className="direct" value="direct">
            직접입력
          </option>
        </select>
        <input
          name="manDirect"
          type="text"
          className="hide"
          id="formInput"
          onChange={(event) => {
            console.log(event.target.value);
          }}
        />
        <button>死</button>
      </form>
    </div>
  );
}

export default App;
